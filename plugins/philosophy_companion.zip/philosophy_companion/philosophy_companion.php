<?php
/*
Plugin Name: Philosophy-Companion
Plugin URI:
Description: Cmpanion plugin for the philosophy theme
Version: 1.0
Author: LWHH
Author URI:
License: GPLv2 or later
Text Domain: philosophy_companion
*/

function philosophy_companion_register_my_cpts_book() {

	/**
	 * Post Type: Books.
	 */

	$labels = [
		"name" => esc_html__( "Books", "philosophy" ),
		"singular_name" => esc_html__( "Book", "philosophy" ),
		"all_items" => esc_html__( "My Books", "philosophy" ),
		"add_new" => esc_html__( "New Book", "philosophy" ),
		"featured_image" => esc_html__( "Book Cover", "philosophy" ),
	];

	$args = [
		"label" => esc_html__( "Books", "philosophy" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"rest_namespace" => "wp/v2",
		"has_archive" => "books",
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => true,
		"can_export" => false,
		"rewrite" => [ "slug" => "note", "with_front" => false ],
		"query_var" => true,
		"menu_position" => 21,
		"menu_icon" => "dashicons-book-alt",
		"supports" => [ "title", "editor", "thumbnail", "excerpt", "author", "page-attributes" ],
		"taxonomies" => [ "category" ],
		"show_in_graphql" => false,
	];

	register_post_type( "book", $args );
}

add_action( 'init', 'philosophy_companion_register_my_cpts_book' );
